<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://urnothemes.com
 * @since      1.0.0
 *
 * @package    Busicon_Elementor_Addons
 * @subpackage Busicon_Elementor_Addons/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
